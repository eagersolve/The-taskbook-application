<?php

$config = [
        'servername' => 'localhost',
        'username' => 'root', //Введите ваш логин от phpmyadmin.
        'db_password' => '151127', //Введите ваш пароль от phpmyadmin.
        'db' => 'task_book'
];
