$(document).ready(function() 
    { 
        $("#myTable").tablesorter({
            headers: {
                2:{
                    sorter:false
                }
            }
        }); 
}); 